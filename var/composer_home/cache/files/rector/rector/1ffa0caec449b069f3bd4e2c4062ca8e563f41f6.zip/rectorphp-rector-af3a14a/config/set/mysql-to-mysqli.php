<?php

declare (strict_types=1);
namespace RectorPrefix202308;

use Rector\Config\RectorConfig;
return static function (RectorConfig $rectorConfig) : void {
    // @deprecated Handle manually with explicit refactoring instead.
};
