<?php

declare (strict_types=1);
namespace Rector\PhpDocParser\PhpDocParser\Exception;

use Exception;
final class InvalidTraverseException extends Exception
{
}
