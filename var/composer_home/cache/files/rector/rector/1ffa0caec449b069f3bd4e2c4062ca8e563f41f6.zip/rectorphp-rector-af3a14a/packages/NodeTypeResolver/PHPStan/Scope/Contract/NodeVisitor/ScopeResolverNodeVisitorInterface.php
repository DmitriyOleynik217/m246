<?php

declare (strict_types=1);
namespace Rector\NodeTypeResolver\PHPStan\Scope\Contract\NodeVisitor;

use PhpParser\NodeVisitor;
interface ScopeResolverNodeVisitorInterface extends NodeVisitor
{
}
